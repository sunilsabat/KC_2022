package day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SimpleLoginScenario {

	public static void main(String[] args) throws InterruptedException {
		
		//Launch the browser
		System.setProperty("webdriver.chrome.driver", ".\\Driver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		//Open URL
		driver.get("https://opensource-demo.orangehrmlive.com/");
		
		//Maximize the browser window
		driver.manage().window().maximize();
		
		//Typing username
		driver.findElement(By.id("txtUsername")).sendKeys("Admin");
		
		//Typing password
		driver.findElement(By.name("txtPassword")).sendKeys("admin123");
		
		//Click login button
		driver.findElement(By.id("btnLogin")).click();
		
		//Click link
		driver.findElement(By.linkText("My Info")).click();

		//Edit my info
		driver.findElement(By.id("btnSave")).click();
		driver.findElement(By.id("personal_txtEmpFirstName")).clear();
		driver.findElement(By.id("personal_txtEmpFirstName")).sendKeys("TestFname");
		driver.findElement(By.name("personal[txtEmpLastName]")).clear();
		driver.findElement(By.name("personal[txtEmpLastName]")).sendKeys("TestLname");
		
		/*css by ID: tagname#id_value
		 * css by classname: tagname.classname_value
		 * css by attribute: tagname[attribute='value of attribute']
		 * */
		
		//Select gender radio button using CSS
		driver.findElement(By.cssSelector("input[value='2']")).click();
		
		//Select nationality
		Select nationality=new Select(driver.findElement(By.id("personal_cmbNation")));		
		nationality.selectByVisibleText("Indian");
		
		Select status=new Select(driver.findElement(By.id("personal_cmbMarital")));
		status.selectByValue("Single");
				
		driver.findElement(By.id("btnSave")).click();	
	
		//logout
		driver.findElement(By.id("welcome")).click();		
		Thread.sleep(2000);
		driver.findElement(By.linkText("Logout")).click();
		
		//Closing browser
		driver.close();
		
	}

}
